#!/bin/sh

export AUTOCONF_VERSION=2.67
export AUTOMAKE_VERSION=1.10

autoreconf

